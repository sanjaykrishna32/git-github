package com.example.sanjaykrishna.contactformsanjay;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity
{
    EditText name,phone,email,message;
    Button submit;
    String userName,phoneNumber,Email,Message;
    public static ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=(EditText)findViewById(R.id.nameEditText);
        phone=(EditText)findViewById(R.id.phoneEditText);
        email=(EditText)findViewById(R.id.emailEditText);
        message=(EditText)findViewById(R.id.messageEditText);
        submit=(Button)findViewById(R.id.button);

        try
        {
            apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Please, Enter a valid url", Toast.LENGTH_LONG).show();
        }

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                userName=name.getText().toString();
                phoneNumber=phone.getText().toString();
                Email=email.getText().toString();
                Message=message.getText().toString();

                if(userName.equals("") || phoneNumber.equals("") || Email.equals("") || Message.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Please fill all the necessary fields", Toast.LENGTH_LONG).show();
                }
                else
                {
                    //code to insert to database
                    Call<AssetData> call = apiInterface.insertAssetData(Message,phoneNumber,Email,userName);
                    call.enqueue(new Callback<AssetData>()
                    {
                        @Override
                        public void onResponse(Call<AssetData> call, final Response<AssetData> response)
                        {
                            try
                            {
                                Toast.makeText(MainActivity.this, ""+response.body().getResponse(), Toast.LENGTH_SHORT).show();
                                name.setText("");
                                phone.setText("");
                                email.setText("");
                                message.setText("");
                            }
                            catch(Exception e)
                            {
                                Toast.makeText(MainActivity.this, ""+e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<AssetData> call, Throwable t) {
                            Toast.makeText(MainActivity.this, ""+t.toString(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
